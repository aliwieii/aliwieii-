import { PrismaClient } from '@prisma/client'; import bcrypt from 'bcryptjs';
const db=new PrismaClient();
async function main(){
 const pass=await bcrypt.hash(process.env.ADMIN_PASSWORD||'change-me-before-deploy',12); await db.user.upsert({where:{email:process.env.ADMIN_EMAIL||'admin@example.com'},update:{passwordHash:pass,role:'ADMIN'},create:{email:process.env.ADMIN_EMAIL||'admin@example.com',passwordHash:pass,name:'ZOON Admin',role:'ADMIN'}});
 const cat=await db.category.upsert({where:{slug:'mugs'},update:{},create:{slug:'mugs',name:'أكواب',description:'أكواب يومية بتصاميم بسيطة'}});
 const products=[['zoon-black-mug','ZON-MUG-001','كوب ZOON الأسود',1500],['zoon-white-mug','ZON-MUG-002','كوب ZOON الأبيض',1500],['zoon-signature-mug','ZON-MUG-003','كوب ZOON المميز',1800],['zoon-daily-mug','ZON-MUG-004','كوب ZOON اليومي',2000]] as const;
 for(const [slug,sku,name,price] of products) await db.product.upsert({where:{sku},update:{},create:{slug,sku,name,price,stock:20,categoryId:cat.id,isFeatured:slug.includes('signature')}});
 for(const [city,area,fee] of [['صنعاء','أمانة العاصمة',1000],['صنعاء','حَدة',1200]] as const) await db.deliveryZone.create({data:{city,area,fee,etaMinDays:1,etaMaxDays:3}}).catch(()=>{});
}
main().finally(()=>db.$disconnect());
